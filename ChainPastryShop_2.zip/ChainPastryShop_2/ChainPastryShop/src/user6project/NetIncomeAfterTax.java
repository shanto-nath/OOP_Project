/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user6project;

/**
 *
 * @author sumiya
 */
public class NetIncomeAfterTax {
    private double netIncome;

    public NetIncomeAfterTax() {
    }

    public double getNetIncome() {
        return netIncome;
    }

    public void setNetIncome(double netIncome) {
        this.netIncome = netIncome;
    }

    @Override
    public String toString() {
        return "NetIncomeAfterTax{" + "netIncome=" + netIncome + '}';
    }
    

}
