/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package HR;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author akash
 */
public class AttandanceController implements Initializable {

    @FXML
    private TableView<Attandance> detailTableView;
    @FXML
    private TableColumn<Attandance, String> dateTableColumn;
    @FXML
    private TableColumn<Attandance, String> employeeIdTableColumn;
    @FXML
    private TableColumn<Attandance, String> employeenameTableColumn;
    @FXML
    private TableColumn<Attandance, String> designationTableColumn;
    @FXML
    private TableColumn<Attandance, String> attandanceStatusTableColumn;
    @FXML
    private TextField employeeIdTextFiled;
    @FXML
    private TextField employeeNaameTextFiled;
    @FXML
    private DatePicker selectDateDatePicker;
    @FXML
    private ComboBox<String> designationComboBox;
    
    ArrayList<Attandance> atgtandanceList;
    ToggleGroup StatusToggleGroup;
    @FXML
    private RadioButton absentRadioButton;
    @FXML
    private RadioButton presentRadioButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        StatusToggleGroup = new ToggleGroup();
        presentRadioButton.setToggleGroup(StatusToggleGroup);
        absentRadioButton.setToggleGroup(StatusToggleGroup);

        designationComboBox.getItems().addAll("HR", "Accountant", "Station Manager", "Train Operator", "Maintenance Staff", "Public Service Provider");

        atgtandanceList = new ArrayList<>();
        
        dateTableColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        employeeIdTableColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        employeenameTableColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        designationTableColumn.setCellValueFactory(new PropertyValueFactory<>("Designation"));
        attandanceStatusTableColumn.setCellValueFactory(new PropertyValueFactory<>("Attandance"));
        // TODO
    }    


    @FXML
    private void viewButtonOnAction(ActionEvent event) {
    }


    @FXML
    private void saveButtonOnClick(ActionEvent event) {
        String status = "";
        if (presentRadioButton.isSelected()) {
            status = "Present";
        } else if (absentRadioButton.isSelected()) {
            status = "Due";
        }
        
        Attandance newAttendance = new Attandance(
                employeeIdTextFiled.getText(),
                employeeNaameTextFiled.getText(),
                designationComboBox.getValue(),
                status,
                selectDateDatePicker.getValue()             
        );
        File f = null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try {
            f = new File("Attendance.bin");
            if(f.exists()) {fos = new FileOutputStream(f,true);}
            else {fos = new FileOutputStream(f);}
            oos = new ObjectOutputStream(fos);
            oos.writeObject(newAttendance);
        } catch (IOException ex) {
            Logger.getLogger(AttandanceController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(AttandanceController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
    

        atgtandanceList.add(newAttendance);
        clearFields();
    

        detailTableView.getItems().clear();
        detailTableView.getItems().addAll(atgtandanceList);
        }

        private void clearFields() {

            employeeIdTextFiled.clear();
            employeeNaameTextFiled.clear();
            StatusToggleGroup.selectToggle(null);
        }
    }
/**
    @FXML
    private void logoutButtonOnAction(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("headofHRDashBoard.fxml"));
        Parent parent = loader.load();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene newScene = new Scene(parent);
        currentStage.setScene(newScene);
        currentStage.show();
        
        
      }
*/
