/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HR;

import java.time.LocalDate;

/**
 *
 * @author akash
 */
public class GrievanceHandiling {
    
    private String  id,name,designation,status;
    private LocalDate showdata;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getShowdata() {
        return showdata;
    }

    public void setShowdata(LocalDate showdata) {
        this.showdata = showdata;
    }

    public GrievanceHandiling(String id, String name, String designation, String status, LocalDate showdata) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.status = status;
        this.showdata = showdata;
    }

    @Override
    public String toString() {
        return "GrievanceHandiling{" + "id=" + id + ", name=" + name + ", designation=" + designation + ", status=" + status + ", showdata=" + showdata + '}';
    }
    
    
    
}
