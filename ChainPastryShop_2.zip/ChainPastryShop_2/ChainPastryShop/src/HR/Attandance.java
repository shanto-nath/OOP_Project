/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HR;

import java.time.LocalDate;

/**
 *
 * @author akash
 */
public class Attandance {
    private String  id,name,designation,status;
    private LocalDate attandDate;

    public Attandance(String id, String name, String designation, String status, LocalDate attandDate) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.status = status;
        this.attandDate = attandDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getAttandDate() {
        return attandDate;
    }

    public void setAttandDate(LocalDate attandDate) {
        this.attandDate = attandDate;
    }

    @Override
    public String toString() {
        return "Attandance{" + "id=" + id + ", name=" + name + ", designation=" + designation + ", status=" + status + ", attandDate=" + attandDate + '}';
    }
    
    
    
}
